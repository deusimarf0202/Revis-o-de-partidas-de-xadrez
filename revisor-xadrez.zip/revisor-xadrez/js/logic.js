/* Lógica do app: motor Stockfish, classificação, precisão, aberturas, explicações, sons e APIs. */
var Lib = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // entry.ts
  var entry_exports = {};
  __export(entry_exports, {
    CLASSIFICATIONS: () => CLASSIFICATIONS,
    SAMPLE_PGN: () => SAMPLE_PGN,
    StockfishEngine: () => StockfishEngine,
    THRESHOLDS: () => THRESHOLDS,
    detectOpening: () => detectOpening,
    evaluatePosition: () => evaluatePosition,
    explainMove: () => explainMove,
    fetchChessComGames: () => fetchChessComGames,
    fetchLichessGames: () => fetchLichessGames,
    formatScore: () => formatScore,
    gameAccuracy: () => gameAccuracy,
    isError: () => isError,
    lineToSteps: () => lineToSteps,
    parsePgn: () => parsePgn,
    playSound: () => playSound,
    reviewMoves: () => reviewMoves,
    soundForSan: () => soundForSan,
    splitUci: () => splitUci,
    terminalEval: () => terminalEval,
    whiteWinChance: () => whiteWinChance,
    winChanceFor: () => winChanceFor
  });

  // src/engine/uci.ts
  function parseInfo(line, sideToMove2) {
    if (!line.startsWith("info ") || /\b(lowerbound|upperbound)\b/.test(line)) return null;
    const depth = /\bdepth (\d+)/.exec(line);
    const score = /\bscore (cp|mate) (-?\d+)/.exec(line);
    const pv = / pv (.+)$/.exec(line);
    if (!depth || !score || !pv) return null;
    const multipv = /\bmultipv (\d+)/.exec(line);
    return {
      depth: Number(depth[1]),
      multipv: multipv ? Number(multipv[1]) : 1,
      score: toWhiteScore(score[1], Number(score[2]), sideToMove2),
      pv: pv[1].trim().split(/\s+/)
    };
  }
  function toWhiteScore(type, raw, sideToMove2) {
    if (type === "cp") return { type, value: sideToMove2 === "w" ? raw : -raw || 0 };
    const other = sideToMove2 === "w" ? "b" : "w";
    return { type, moves: Math.abs(raw), winner: raw > 0 ? sideToMove2 : other };
  }
  var sideToMove = (fen) => fen.split(" ")[1] === "b" ? "b" : "w";

  // src/engine/StockfishEngine.ts
  var SF18 = "https://cdn.jsdelivr.net/npm/stockfish@18.0.8/bin/stockfish-18-lite-single";
  var SOURCES = [
    { js: `${SF18}.js`, wasm: `${SF18}.wasm`, timeout: 4e4 },
    { js: "https://cdnjs.cloudflare.com/ajax/libs/stockfish.js/10.0.2/stockfish.js", timeout: 4e4 }
  ];
  var abortError = () => new DOMException("Análise cancelada", "AbortError");
  var StockfishEngine = class {
    worker = null;
    booting = null;
    queue = Promise.resolve();
    listener = null;
    fail = null;
    disposed = false;
    analyze(fen, options) {
      const run = this.queue.then(() => this.search(fen, options));
      this.queue = run.catch(() => void 0);
      return run;
    }
    dispose() {
      this.disposed = true;
      this.fail?.(abortError());
      this.reset();
    }
    reset() {
      this.worker?.terminate();
      this.worker = null;
      this.booting = null;
      this.listener = null;
      this.fail = null;
    }
    boot() {
      this.booting ??= this.createWorker().catch((error) => {
        this.reset();
        throw error;
      });
      return this.booting;
    }
    async createWorker() {
      let lastError = null;
      for (const source of SOURCES) {
        if (this.disposed) throw abortError();
        try {
          return await this.startWorker(source);
        } catch (error) {
          lastError = error;
          this.worker?.terminate();
          this.worker = null;
          if (this.disposed) throw abortError();
        }
      }
      throw new Error(`Não foi possível carregar o Stockfish. Verifique sua internet. (${lastError?.message})`);
    }
    async startWorker(source) {
      const blob = new Blob([`importScripts(${JSON.stringify(source.js)});`], { type: "text/javascript" });
      const hash = source.wasm ? `#${encodeURIComponent(source.wasm)}` : "";
      const worker = new Worker(URL.createObjectURL(blob) + hash);
      this.worker = worker;
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("O Stockfish não respondeu ao iniciar.")), source.timeout);
        const stop = (error) => {
          clearTimeout(timer);
          reject(error);
        };
        this.fail = stop;
        worker.onerror = (event) => {
          event.preventDefault?.();
          (this.fail ?? stop)(new Error("Falha no Web Worker do Stockfish."));
        };
        worker.onmessage = (event) => {
          for (const line of String(event.data).split("\n")) {
            if (line === "uciok") worker.postMessage("isready");
            else if (line === "readyok" && !this.listener) {
              clearTimeout(timer);
              this.fail = null;
              resolve();
            } else this.listener?.(line);
          }
        };
        worker.postMessage("uci");
      });
      return worker;
    }
    async search(fen, options) {
      const { depth, movetime, multiPv = 1, signal, onUpdate } = options;
      if (signal?.aborted || this.disposed) throw abortError();
      const worker = await this.boot();
      if (signal?.aborted || this.disposed) throw abortError();
      const turn = sideToMove(fen);
      const lines = [];
      return new Promise((resolve, reject) => {
        let hardStop;
        const onAbort = () => worker.postMessage("stop");
        const cleanup = () => {
          clearTimeout(softStop);
          clearTimeout(hardStop);
          signal?.removeEventListener("abort", onAbort);
          this.listener = null;
          this.fail = null;
        };
        const softStop = setTimeout(() => {
          worker.postMessage("stop");
          hardStop = setTimeout(() => this.fail?.(new Error("O Stockfish parou de responder.")), 3e3);
        }, movetime + 5e3);
        this.fail = (error) => {
          cleanup();
          this.reset();
          reject(error);
        };
        this.listener = (line) => {
          if (line.startsWith("bestmove")) {
            cleanup();
            if (signal?.aborted) reject(abortError());
            else if (!lines.length) reject(new Error("O Stockfish não retornou uma avaliação."));
            else resolve(lines.filter(Boolean));
            return;
          }
          const info = parseInfo(line, turn);
          if (!info) return;
          lines[info.multipv - 1] = { score: info.score, depth: info.depth, pv: info.pv };
          if (info.multipv === 1) onUpdate?.(lines.filter(Boolean));
        };
        signal?.addEventListener("abort", onAbort, { once: true });
        worker.postMessage(`setoption name MultiPV value ${multiPv}`);
        worker.postMessage(`position fen ${fen}`);
        worker.postMessage(`go depth ${depth} movetime ${movetime}`);
      });
    }
  };

  // chess-shim.js
  var Chess = globalThis.Chess;
  var DEFAULT_POSITION = globalThis.DEFAULT_POSITION;

  // src/engine/evaluatePosition.ts
  function terminalEval(fen) {
    const chess = new Chess(fen);
    if (chess.isCheckmate()) {
      const winner = sideToMove(fen) === "w" ? "b" : "w";
      return { lines: [], score: { type: "mate", moves: 0, winner } };
    }
    if (chess.isStalemate() || chess.isInsufficientMaterial()) {
      return { lines: [], score: { type: "cp", value: 0 } };
    }
    return null;
  }
  async function evaluatePosition(engine, fen, options) {
    const terminal = terminalEval(fen);
    if (terminal) return terminal;
    const lines = await engine.analyze(fen, options);
    return { lines, score: lines[0].score };
  }

  // src/lib/pgn.ts
  function firstGame(pgn) {
    const text = pgn.replace(/^﻿/, "").replace(/\r\n?/g, "\n").trim();
    const next = /\n\s*\n(?=\[Event )/.exec(text);
    return next ? text.slice(0, next.index) : text;
  }
  function parsePgn(pgn) {
    const chess = new Chess();
    try {
      chess.loadPgn(firstGame(pgn));
    } catch (error) {
      throw new Error(`PGN inválido: ${error instanceof Error ? error.message : "formato não reconhecido"}`);
    }
    const headers = {};
    for (const [key, value] of Object.entries(chess.getHeaders())) if (value) headers[key] = String(value);
    if (headers.Variant && !/^(standard|from position)$/i.test(headers.Variant)) {
      throw new Error(`Variante "${headers.Variant}" não é suportada.`);
    }
    const moves = chess.history({ verbose: true }).map((m) => ({
      san: m.san,
      uci: m.from + m.to + (m.promotion ?? ""),
      from: m.from,
      to: m.to,
      color: m.color,
      piece: m.piece,
      captured: m.captured,
      fenBefore: m.before,
      fenAfter: m.after
    }));
    if (!moves.length) throw new Error("Nenhum lance encontrado no PGN.");
    const rating = (v) => v && v !== "?" ? v : void 0;
    const name = (v, fallback) => v && v !== "?" ? v : fallback;
    return {
      id: crypto.randomUUID?.() ?? String(Date.now()),
      headers,
      white: { name: name(headers.White, "Brancas"), rating: rating(headers.WhiteElo) },
      black: { name: name(headers.Black, "Pretas"), rating: rating(headers.BlackElo) },
      result: headers.Result ?? "*",
      startFen: moves[0].fenBefore ?? DEFAULT_POSITION,
      moves
    };
  }

  // src/lib/samplePgn.ts
  var SAMPLE_PGN = `[Event "Partida da Ópera"]
[Site "Paris"]
[Date "1858.??.??"]
[White "Paul Morphy"]
[Black "Duque de Brunswick e Conde Isouard"]
[Result "1-0"]

1. e4 e5 2. Nf3 d6 3. d4 Bg4 4. dxe5 Bxf3 5. Qxf3 dxe5 6. Bc4 Nf6 7. Qb3 Qe7
8. Nc3 c6 9. Bg5 b5 10. Nxb5 cxb5 11. Bxb5+ Nbd7 12. O-O-O Rd8 13. Rxd7 Rxd7
14. Rd1 Qe6 15. Bxd7+ Nxd7 16. Qb8+ Nxb8 17. Rd8# 1-0`;

  // src/lib/openings.ts
  var OPENING_TABLE = `
A00|Abertura Húngara|g3
A00|Abertura Polonesa|b4
A01|Abertura Larsen|b3
A02|Abertura Bird|f4
A04|Abertura Réti|Nf3
A06|Abertura Réti|Nf3 d5
A09|Gambito Réti|Nf3 d5 c4
A10|Abertura Inglesa|c4
A20|Inglesa: Siciliana Invertida|c4 e5
A30|Inglesa Simétrica|c4 c5
A40|Abertura do Peão da Dama|d4
A43|Defesa Benoni Antiga|d4 c5
A45|Abertura do Peão da Dama: Defesa Índia|d4 Nf6
A45|Ataque Trompowsky|d4 Nf6 Bg5
A46|Sistema Londres (contra ...Cf6)|d4 Nf6 Nf3 e6 Bf4
A51|Gambito Budapeste|d4 Nf6 c4 e5
A57|Gambito Benko|d4 Nf6 c4 c5 d5 b5
A60|Benoni Moderna|d4 Nf6 c4 c5 d5 e6
A80|Defesa Holandesa|d4 f5
B00|Abertura do Peão do Rei|e4
B00|Defesa Nimzowitsch|e4 Nc6
B01|Defesa Escandinava|e4 d5
B01|Escandinava: Variante Principal|e4 d5 exd5 Qxd5 Nc3 Qa5
B02|Defesa Alekhine|e4 Nf6
B06|Defesa Moderna|e4 g6
B07|Defesa Pirc|e4 d6 d4 Nf6 Nc3 g6
B10|Defesa Caro-Kann|e4 c6
B12|Caro-Kann: Variante do Avanço|e4 c6 d4 d5 e5
B13|Caro-Kann: Variante das Trocas|e4 c6 d4 d5 exd5 cxd5
B15|Caro-Kann: 3.Cc3|e4 c6 d4 d5 Nc3
B18|Caro-Kann: Variante Clássica|e4 c6 d4 d5 Nc3 dxe4 Nxe4 Bf5
B20|Defesa Siciliana|e4 c5
B22|Siciliana: Variante Alapin|e4 c5 c3
B23|Siciliana Fechada|e4 c5 Nc3
B27|Siciliana: 2.Cf3|e4 c5 Nf3
B30|Siciliana: 2...Cc6|e4 c5 Nf3 Nc6
B30|Siciliana: Variante Rossolimo|e4 c5 Nf3 Nc6 Bb5
B32|Siciliana Aberta|e4 c5 Nf3 Nc6 d4 cxd4 Nxd4
B33|Siciliana: Variante Sveshnikov|e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 e5
B40|Siciliana: 2...e6|e4 c5 Nf3 e6
B50|Siciliana: 2...d6|e4 c5 Nf3 d6
B51|Siciliana: Variante Moscou|e4 c5 Nf3 d6 Bb5+
B70|Siciliana: Variante do Dragão|e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6
B80|Siciliana: Scheveningen|e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 e6
B90|Siciliana: Variante Najdorf|e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6
C00|Defesa Francesa|e4 e6
C01|Francesa: Variante das Trocas|e4 e6 d4 d5 exd5
C02|Francesa: Variante do Avanço|e4 e6 d4 d5 e5
C03|Francesa: Variante Tarrasch|e4 e6 d4 d5 Nd2
C10|Francesa: 3.Cc3|e4 e6 d4 d5 Nc3
C15|Francesa: Variante Winawer|e4 e6 d4 d5 Nc3 Bb4
C20|Partida Aberta|e4 e5
C21|Gambito Dinamarquês|e4 e5 d4 exd4 c3
C23|Abertura do Bispo|e4 e5 Bc4
C25|Abertura Vienense|e4 e5 Nc3
C30|Gambito do Rei|e4 e5 f4
C33|Gambito do Rei Aceito|e4 e5 f4 exf4
C40|Abertura do Cavalo do Rei|e4 e5 Nf3
C41|Defesa Philidor|e4 e5 Nf3 d6
C42|Defesa Petrov|e4 e5 Nf3 Nf6
C44|Partida do Cavalo do Rei: 2...Cc6|e4 e5 Nf3 Nc6
C45|Abertura Escocesa|e4 e5 Nf3 Nc6 d4
C46|Três Cavalos|e4 e5 Nf3 Nc6 Nc3
C47|Quatro Cavalos|e4 e5 Nf3 Nc6 Nc3 Nf6
C50|Abertura Italiana|e4 e5 Nf3 Nc6 Bc4
C50|Italiana: Giuoco Piano|e4 e5 Nf3 Nc6 Bc4 Bc5
C51|Gambito Evans|e4 e5 Nf3 Nc6 Bc4 Bc5 b4
C55|Defesa dos Dois Cavalos|e4 e5 Nf3 Nc6 Bc4 Nf6
C57|Dois Cavalos: 4.Cg5|e4 e5 Nf3 Nc6 Bc4 Nf6 Ng5
C60|Ruy López (Espanhola)|e4 e5 Nf3 Nc6 Bb5
C65|Ruy López: Defesa Berlinense|e4 e5 Nf3 Nc6 Bb5 Nf6
C68|Ruy López: Variante das Trocas|e4 e5 Nf3 Nc6 Bb5 a6 Bxc6
C70|Ruy López: 4.Ba4|e4 e5 Nf3 Nc6 Bb5 a6 Ba4
C84|Ruy López Fechada|e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7
D00|Partida do Peão da Dama|d4 d5
D00|Sistema Londres|d4 d5 Bf4
D02|Sistema Londres|d4 d5 Nf3 Nf6 Bf4
D06|Gambito da Dama|d4 d5 c4
D10|Defesa Eslava|d4 d5 c4 c6
D20|Gambito da Dama Aceito|d4 d5 c4 dxc4
D30|Gambito da Dama Recusado|d4 d5 c4 e6
D35|Gambito da Dama: Variante das Trocas|d4 d5 c4 e6 Nc3 Nf6 cxd5
D43|Defesa Semi-Eslava|d4 d5 c4 c6 Nf3 Nf6 Nc3 e6
D70|Defesa Neo-Grünfeld|d4 Nf6 c4 g6 f3 d5
D80|Defesa Grünfeld|d4 Nf6 c4 g6 Nc3 d5
E00|Defesa Índia: 2...e6|d4 Nf6 c4 e6
E01|Abertura Catalã|d4 Nf6 c4 e6 g3
E12|Defesa Índia da Dama|d4 Nf6 c4 e6 Nf3 b6
E20|Defesa Nimzo-Índia|d4 Nf6 c4 e6 Nc3 Bb4
E60|Defesa Índia do Rei|d4 Nf6 c4 g6
E70|Índia do Rei: 4.e4|d4 Nf6 c4 g6 Nc3 Bg7 e4
E90|Índia do Rei: Variante Clássica|d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 Nf3
`.trim().split("\n").map((row) => {
    const [eco, name, line] = row.split("|");
    return { eco, name, moves: line.split(" ") };
  });
  var strip = (san) => san.replace(/[+#!?]/g, "");
  function detectOpening(sans, headers = {}) {
    let match = null;
    for (const entry of headers.FEN ? [] : OPENING_TABLE) {
      const fits = entry.moves.every((m, i) => sans[i] !== void 0 && strip(sans[i]) === strip(m));
      if (fits && (!match || entry.moves.length > match.moves.length)) match = entry;
    }
    const fromUrl = headers.ECOUrl?.split("/openings/")[1]?.replace(/-/g, " ");
    const headerName = headers.Opening || fromUrl;
    const bookPlies = match?.moves.length ?? 0;
    if (headerName && headerName !== "?") return { eco: headers.ECO ?? match?.eco ?? "", name: headerName, bookPlies };
    if (match) return { eco: headers.ECO ?? match.eco, name: match.name, bookPlies };
    return headers.ECO ? { eco: headers.ECO, name: "Abertura não catalogada", bookPlies } : null;
  }

  // src/lib/score.ts
  function whiteWinChance(score) {
    if (score.type === "mate") return score.winner === "w" ? 100 : 0;
    const cp = Math.max(-1e3, Math.min(1e3, score.value));
    return 50 + 50 * (2 / (1 + Math.exp(-368208e-8 * cp)) - 1);
  }
  var winChanceFor = (score, color) => color === "w" ? whiteWinChance(score) : 100 - whiteWinChance(score);
  function formatScore(score) {
    if (score.type === "mate") {
      if (score.moves === 0) return score.winner === "w" ? "1-0" : "0-1";
      return `${score.winner === "w" ? "" : "-"}M${score.moves}`;
    }
    const pawns = score.value / 100;
    return `${pawns > 0 ? "+" : ""}${pawns.toFixed(2)}`;
  }

  // src/lib/accuracy.ts
  var clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  var moveAccuracy = (winLoss) => clamp(103.1668 * Math.exp(-0.04354 * Math.max(0, winLoss)) - 3.1669, 0, 100);
  function stdDev(values) {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return Math.sqrt(values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length);
  }
  function gameAccuracy(scores, accuracies, colors) {
    const wins = scores.map(whiteWinChance);
    const size = clamp(Math.floor(accuracies.length / 10), 2, 8);
    const weights = accuracies.map((_, i) => {
      const start = clamp(i + 1 - Math.floor(size / 2), 0, Math.max(0, wins.length - size));
      return clamp(stdDev(wins.slice(start, start + size)), 0.5, 12);
    });
    const forColor = (color) => {
      const idx = colors.flatMap((c, i) => c === color ? [i] : []);
      if (!idx.length) return null;
      const totalWeight = idx.reduce((a, i) => a + weights[i], 0);
      const weighted = idx.reduce((a, i) => a + accuracies[i] * weights[i], 0) / totalWeight;
      const harmonic = idx.length / idx.reduce((a, i) => a + 1 / Math.max(accuracies[i], 1), 0);
      return clamp((weighted + harmonic) / 2, 0, 100);
    };
    return { w: forColor("w"), b: forColor("b") };
  }

  // src/lib/classify.ts
  var THRESHOLDS = {
    /** Perdas de chance de vitória, em pontos percentuais. */
    inaccuracy: 5,
    mistake: 10,
    blunder: 20,
    /** Distância mínima para a 2ª melhor linha para um lance valer "!". */
    onlyMove: 10
  };
  function classifyMove(input) {
    const { color, uci, before, after } = input;
    const [first, second] = before.lines;
    const bestUci = first?.pv[0];
    const isBest = uci === bestUci;
    const winBefore = winChanceFor(before.score, color);
    const winAfter = winChanceFor(after.score, color);
    const delivered = after.score.type === "mate" && after.score.moves === 0;
    const winLoss = isBest || delivered ? 0 : Math.max(0, winBefore - winAfter);
    const hadMate = before.score.type === "mate" && before.score.winner === color;
    const keptMate = after.score.type === "mate" && after.score.winner === color;
    const result = (classification) => ({
      classification,
      winLoss,
      accuracy: classification === "book" ? 100 : moveAccuracy(winLoss),
      bestUci
    });
    if (input.isBook && winLoss < THRESHOLDS.mistake) return result("book");
    if (winLoss >= THRESHOLDS.blunder) return result("blunder");
    if (winLoss >= THRESHOLDS.mistake) return result("mistake");
    if (winLoss >= THRESHOLDS.inaccuracy || hadMate && !keptMate) return result("inaccuracy");
    const secondWin = second ? winChanceFor(second.score, color) : null;
    const nearBest = isBest || winLoss < 2;
    if (nearBest && input.isSacrifice && winAfter >= 45 && (secondWin === null || secondWin < 95)) {
      return result("brilliant");
    }
    if (isBest && !delivered && input.legalMoves > 1 && !input.isRecapture && secondWin !== null && winBefore - secondWin >= THRESHOLDS.onlyMove) {
      return result("great");
    }
    return result(isBest || delivered ? "best" : "good");
  }

  // src/lib/sacrifice.ts
  var VALUE = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };
  function exchangeGain(chess, square) {
    const captures = chess.moves({ verbose: true }).filter((m) => m.to === square && m.captured).sort((a, b) => VALUE[a.piece] - VALUE[b.piece]);
    if (!captures.length) return 0;
    const move = captures[0];
    chess.move(move);
    const gain = VALUE[move.captured] - exchangeGain(chess, square);
    chess.undo();
    return Math.max(0, gain);
  }
  function isSacrifice(move) {
    if (move.piece === "p" || move.piece === "k") return false;
    const gain = exchangeGain(new Chess(move.fenAfter), move.to);
    return gain - (move.captured ? VALUE[move.captured] : 0) >= 2;
  }

  // src/lib/review.ts
  function reviewMoves(game, evals, opening) {
    return game.moves.map((move, i) => {
      const before = evals[i];
      const after = evals[i + 1];
      if (!before || !after) return void 0;
      const previous = game.moves[i - 1];
      return {
        before,
        after,
        ...classifyMove({
          color: move.color,
          uci: move.uci,
          before,
          after,
          isBook: i < (opening?.bookPlies ?? 0),
          isSacrifice: isSacrifice(move),
          isRecapture: Boolean(previous?.captured && previous.to === move.to),
          legalMoves: new Chess(move.fenBefore).moves().length
        })
      };
    });
  }

  // src/lib/classificationMeta.ts
  var CLASSIFICATIONS = {
    brilliant: { label: "Brilhante", symbol: "!!", color: "#1ec9b7" },
    great: { label: "Excelente", symbol: "!", color: "#5b9bf5" },
    best: { label: "Melhor lance", symbol: "★", color: "#7fc243" },
    book: { label: "Teórico", symbol: "≡", color: "#b8956a" },
    good: { label: "Bom", symbol: "✓", color: "#8fb08a" },
    inaccuracy: { label: "Imprecisão", symbol: "?!", color: "#f2c230" },
    mistake: { label: "Erro", symbol: "?", color: "#ee8a2c" },
    blunder: { label: "Erro grave", symbol: "??", color: "#e8453c" }
  };
  var isError = (c) => c === "inaccuracy" || c === "mistake" || c === "blunder";

  // src/lib/explain.ts
  var PIECES = { p: "um peão", n: "um cavalo", b: "um bispo", r: "uma torre", q: "a dama" };
  function standing(score, color) {
    const win = winChanceFor(score, color);
    if (win >= 85) return "posição ganhadora";
    if (win >= 65) return "clara vantagem";
    if (win >= 55) return "leve vantagem";
    if (win > 45) return "equilíbrio";
    if (win > 35) return "leve desvantagem";
    if (win > 15) return "clara desvantagem";
    return "posição perdida";
  }
  function explainMove(move, review, context2) {
    const { classification, before, after, winLoss } = review;
    const side = move.color === "w" ? "as brancas" : "as pretas";
    const text = [];
    if (after.score.type === "mate" && after.score.moves === 0) return ["Xeque-mate! O lance encerra a partida."];
    const intro = {
      brilliant: `${move.san} é um sacrifício correto: entrega material e ainda assim é a escolha do motor ou está muito perto dela.`,
      great: `${move.san} era o único lance que preservava a avaliação; as alternativas eram bem piores.`,
      best: `${move.san} é a primeira escolha do Stockfish.`,
      book: `${move.san} segue a teoria de aberturas.`,
      good: `${move.san} é um lance sólido, com perda pequena em relação ao ideal.`,
      inaccuracy: `${move.san} é impreciso e desperdiça parte das chances.`,
      mistake: `${move.san} é um erro que piora bastante a posição.`,
      blunder: `${move.san} é um erro grave.`
    }[classification];
    text.push(intro);
    const hadMate = before.score.type === "mate" && before.score.winner === move.color;
    const keptMate = after.score.type === "mate" && after.score.winner === move.color;
    const getsMated = after.score.type === "mate" && after.score.winner !== move.color;
    const wasMated = before.score.type === "mate" && before.score.winner !== move.color;
    if (hadMate && !keptMate && before.score.type === "mate") {
      text.push(`Havia mate forçado em ${before.score.moves} e a oportunidade foi perdida.`);
    }
    if (getsMated && !wasMated && after.score.type === "mate") {
      text.push(`Permite mate forçado em ${after.score.moves} para o adversário.`);
    }
    const reply = after.lines[0]?.pv[0];
    if (winLoss >= 10 && context2.replySan) {
      const takes = context2.replySan.includes("x") && reply?.slice(2, 4) === move.to;
      text.push(
        takes ? `O adversário pode responder ${context2.replySan}, capturando ${PIECES[move.piece] ?? "a peça"} recém-movido(a).` : `A resposta mais forte do adversário é ${context2.replySan}.`
      );
    }
    const from = standing(before.score, move.color);
    const to = standing(after.score, move.color);
    text.push(
      from === to ? `Para ${side}, a situação continua de ${to}.` : `Para ${side}, a situação passa de ${from} para ${to}.`
    );
    if (context2.bestSan && review.bestUci !== move.uci && classification !== "book") {
      text.push(`O melhor era ${context2.bestSan} (seta verde no tabuleiro).`);
    }
    return text;
  }

  // src/lib/chessUtils.ts
  var splitUci = (uci) => ({
    from: uci.slice(0, 2),
    to: uci.slice(2, 4),
    promotion: uci.slice(4, 5) || void 0
  });
  function lineToSteps(fen, pv, limit = 10) {
    const chess = new Chess(fen);
    const steps = [];
    for (const uci of pv.slice(0, limit)) {
      const number = chess.moveNumber();
      const turn = chess.turn();
      try {
        const move = chess.move(splitUci(uci));
        const prefix = turn === "w" ? `${number}. ` : steps.length === 0 ? `${number}… ` : "";
        steps.push({ san: move.san, uci, fen: chess.fen(), label: prefix + move.san });
      } catch {
        break;
      }
    }
    return steps;
  }

  // src/lib/sounds.ts
  var context = null;
  function audio() {
    if (typeof AudioContext === "undefined") return null;
    context ??= new AudioContext();
    if (context.state === "suspended") void context.resume();
    return context;
  }
  function knock(ctx, at, frequency, volume) {
    const length = Math.floor(ctx.sampleRate * 0.09);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (length * 0.12));
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = frequency;
    filter.Q.value = 1.4;
    const gain = ctx.createGain();
    gain.gain.value = volume;
    source.connect(filter).connect(gain).connect(ctx.destination);
    source.start(at);
  }
  function tone(ctx, at, frequency, duration, volume = 0.12) {
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = "triangle";
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(volume, at);
    gain.gain.exponentialRampToValueAtTime(1e-3, at + duration);
    oscillator.connect(gain).connect(ctx.destination);
    oscillator.start(at);
    oscillator.stop(at + duration);
  }
  function playSound(name) {
    const ctx = audio();
    if (!ctx) return;
    const t = ctx.currentTime;
    switch (name) {
      case "move":
        knock(ctx, t, 900, 0.9);
        break;
      case "capture":
        knock(ctx, t, 1600, 1.1);
        knock(ctx, t + 0.035, 700, 0.9);
        break;
      case "check":
        knock(ctx, t, 900, 0.8);
        tone(ctx, t + 0.02, 880, 0.18);
        break;
      case "end":
        [523, 392, 262].forEach((f, i) => tone(ctx, t + i * 0.14, f, 0.35));
        break;
      case "success":
        [523, 784].forEach((f, i) => tone(ctx, t + i * 0.1, f, 0.22));
        break;
      case "fail":
        [220, 165].forEach((f, i) => tone(ctx, t + i * 0.12, f, 0.25));
        break;
    }
  }
  function soundForSan(san, isLast) {
    if (san.includes("#") || isLast) return "end";
    if (san.includes("+")) return "check";
    return san.includes("x") ? "capture" : "move";
  }

  // src/services/chesscom.ts
  var API = "https://api.chess.com/pub/player";
  async function getJson(url, signal) {
    const response = await fetch(url, { signal });
    if (response.status === 404) throw new Error("Usuário não encontrado no Chess.com.");
    if (response.status === 429) throw new Error("Chess.com limitou as requisições. Tente em instantes.");
    if (!response.ok) throw new Error(`Chess.com respondeu com erro ${response.status}.`);
    return response.json();
  }
  async function fetchChessComGames(username, signal, max = 10) {
    const user = encodeURIComponent(username.trim().toLowerCase());
    const { archives } = await getJson(`${API}/${user}/games/archives`, signal);
    const games = [];
    for (let i = archives.length - 1; i >= 0 && games.length < max; i--) {
      const month = await getJson(archives[i], signal);
      const valid = month.games.filter((g) => g.rules === "chess" && g.pgn).sort((a, b) => b.end_time - a.end_time);
      for (const g of valid.slice(0, max - games.length)) {
        games.push({
          id: g.url,
          white: { name: g.white.username, rating: g.white.rating },
          black: { name: g.black.username, rating: g.black.rating },
          result: g.white.result === "win" ? "1-0" : g.black.result === "win" ? "0-1" : "½-½",
          speed: g.time_class,
          date: g.end_time * 1e3,
          pgn: g.pgn
        });
      }
    }
    return games;
  }

  // src/services/lichess.ts
  var player = (p) => ({
    name: p.user?.name ?? (p.aiLevel ? `Stockfish nível ${p.aiLevel}` : "Anônimo"),
    rating: p.rating
  });
  async function fetchLichessGames(username, signal, max = 10) {
    const params = new URLSearchParams({
      max: String(max),
      pgnInJson: "true",
      opening: "true",
      // Somente xadrez padrão.
      perfType: "ultraBullet,bullet,blitz,rapid,classical,correspondence"
    });
    const response = await fetch(
      `https://lichess.org/api/games/user/${encodeURIComponent(username.trim())}?${params}`,
      { headers: { Accept: "application/x-ndjson" }, signal }
    );
    if (response.status === 404) throw new Error("Usuário não encontrado no Lichess.");
    if (response.status === 429) throw new Error("Lichess limitou as requisições. Aguarde um minuto.");
    if (!response.ok) throw new Error(`Lichess respondeu com erro ${response.status}.`);
    return (await response.text()).split("\n").filter((line) => line.trim()).map((line) => JSON.parse(line)).filter((g) => g.variant === "standard" && g.pgn).map((g) => ({
      id: g.id,
      white: player(g.players.white),
      black: player(g.players.black),
      result: g.winner === "white" ? "1-0" : g.winner === "black" ? "0-1" : "½-½",
      speed: g.speed,
      date: g.createdAt,
      pgn: g.pgn
    }));
  }
  return __toCommonJS(entry_exports);
})();
