/* Interface: estado do app, desenho da tela e eventos. */
(function () {
  'use strict';

  const PRESETS = {
    fast: { depth: 11, movetime: 700 },
    normal: { depth: 14, movetime: 1800 },
    deep: { depth: 18, movetime: 6000 },
  };
  // U+FE0E força o desenho como texto (evita o peão virar emoji).
  const GLYPH = { k: '♚︎', q: '♛︎', r: '♜︎', b: '♝︎', n: '♞︎', p: '♟︎' };
  const NOTABLE = ['brilliant', 'great', 'inaccuracy', 'mistake', 'blunder'];

  const $ = (id) => document.getElementById(id);
  const escapeHtml = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  /** Só altera o DOM quando o conteúdo muda (preserva foco e cliques durante a análise). */
  const setHtml = (element, html) => {
    if (element._html !== html) element.innerHTML = element._html = html;
  };

  const analysisEngine = new Lib.StockfishEngine();
  const liveEngine = new Lib.StockfishEngine();

  const state = {
    game: null,
    opening: null,
    evals: [],
    reviews: [],
    accuracy: null,
    error: '',
    ply: 0,
    flipped: false,
    muted: false,
    preview: null, // índice do lance explorado na linha recomendada
    retry: null,
    selected: null,
    promotion: null,
    live: null,
  };
  let analysisAbort, liveAbort, retryAbort, liveFen, playTimer;

  const sound = (name) => { if (!state.muted) Lib.playSound(name); };

  /* ---------- Análise ---------- */

  async function analyze() {
    analysisAbort?.abort();
    const abort = (analysisAbort = new AbortController());
    const { game } = state;
    const preset = PRESETS[$('preset').value];
    Object.assign(state, { evals: [], reviews: [], accuracy: null, error: '', live: null, preview: null });
    stopRetry();
    render();
    try {
      const fens = [game.startFen, ...game.moves.map((m) => m.fenAfter)];
      for (const fen of fens) {
        const result = await Lib.evaluatePosition(analysisEngine, fen, { ...preset, multiPv: 2, signal: abort.signal });
        if (abort.signal.aborted) return;
        state.evals.push(result);
        state.reviews = Lib.reviewMoves(game, state.evals, state.opening);
        if (state.evals.length === fens.length) {
          state.accuracy = Lib.gameAccuracy(
            state.evals.map((e) => e.score),
            state.reviews.map((r) => r.accuracy),
            game.moves.map((m) => m.color),
          );
        }
        render();
      }
    } catch (error) {
      if (abort.signal.aborted) return;
      state.error = error.message;
      render();
    }
  }

  /** Avalia em tempo real posições que a análise principal ainda não cobriu. */
  function updateLive(fen) {
    if (fen === liveFen) return;
    liveAbort?.abort();
    liveFen = fen;
    if (!fen) return;
    const terminal = Lib.terminalEval(fen);
    if (terminal) {
      state.live = { fen, value: terminal };
      return queueMicrotask(render);
    }
    const abort = (liveAbort = new AbortController());
    liveEngine
      .analyze(fen, {
        depth: 17,
        movetime: 3500,
        signal: abort.signal,
        onUpdate: (lines) => {
          if (abort.signal.aborted) return;
          state.live = { fen, value: { lines, score: lines[0].score } };
          render();
        },
      })
      .catch(() => {});
  }

  /* ---------- Navegação ---------- */

  function loadGame(game) {
    pause();
    state.game = game;
    state.opening = Lib.detectOpening(game.moves.map((m) => m.san), game.headers);
    state.ply = 0;
    liveFen = undefined;
    analyze();
  }

  function goTo(target) {
    const { game } = state;
    const next = Math.max(0, Math.min(game.moves.length, target));
    const changed = next !== state.ply;
    state.ply = next;
    state.preview = null;
    stopRetry();
    const move = game.moves[next - 1];
    if (changed && move) sound(Lib.soundForSan(move.san, next === game.moves.length && game.result !== '*'));
    render();
  }

  const jump = (target) => { pause(); goTo(target); };

  function pause() {
    clearInterval(playTimer);
    playTimer = undefined;
  }

  function togglePlay() {
    if (playTimer) {
      pause();
    } else {
      if (state.ply >= state.game.moves.length) state.ply = 0;
      playTimer = setInterval(() => {
        goTo(state.ply + 1);
        if (state.ply >= state.game.moves.length) { pause(); render(); }
      }, 1000);
    }
    render();
  }

  /* ---------- Tentar novamente ---------- */

  function stopRetry() {
    retryAbort?.abort();
    state.retry = null;
    state.selected = null;
    state.promotion = null;
  }

  function startRetry() {
    const move = state.game.moves[state.ply - 1];
    const review = state.reviews[state.ply - 1];
    if (!move || !review) return;
    pause();
    stopRetry();
    state.preview = null;
    state.retry = {
      move, review, status: 'waiting', fen: move.fenBefore, hint: false, revealed: false,
      message: 'Encontre um lance melhor: arraste a peça ou clique na origem e no destino.',
    };
    render();
  }

  function attempt(from, to, promotion) {
    const retry = state.retry;
    const chess = new Chess(retry.move.fenBefore);
    const played = chess.move({ from, to, promotion });
    const uci = played.from + played.to + (played.promotion ?? '');
    Object.assign(retry, { fen: chess.fen(), attempt: { from, to } });
    const finish = (solved, message) => {
      Object.assign(retry, { status: solved ? 'solved' : 'wrong', message });
      sound(solved ? 'success' : 'fail');
      render();
    };
    if (uci === retry.review.bestUci || chess.isCheckmate()) return finish(true, `Isso! ${played.san} é a melhor continuação.`);
    if (uci === retry.move.uci) return finish(false, `${played.san} foi o lance jogado na partida. Procure algo melhor.`);

    retryAbort?.abort();
    const abort = (retryAbort = new AbortController());
    Object.assign(retry, { status: 'checking', message: `Analisando ${played.san}…` });
    render();
    Lib.evaluatePosition(liveEngine, retry.fen, { depth: 14, movetime: 2000, signal: abort.signal })
      .then((result) => {
        if (abort.signal.aborted) return;
        const { color } = retry.move;
        const loss = Lib.winChanceFor(retry.review.before.score, color) - Lib.winChanceFor(result.score, color);
        if (loss < Lib.THRESHOLDS.inaccuracy) finish(true, `${played.san} também é um bom lance.`);
        else finish(false, `${played.san} ainda não é suficiente. Tente de novo.`);
      })
      .catch((error) => { if (!abort.signal.aborted) finish(false, error.message); });
  }

  /* ---------- Tela ---------- */

  /** Tudo o que depende da posição exibida. */
  function view() {
    const { game, ply, retry } = state;
    const move = game.moves[ply - 1];
    const review = state.reviews[ply - 1];
    const bestLine = move && review?.before.lines[0] ? Lib.lineToSteps(move.fenBefore, review.before.lines[0].pv) : [];
    const step = state.preview === null ? undefined : bestLine[state.preview];
    const fen = retry?.fen ?? step?.fen ?? move?.fenAfter ?? game.startFen;
    const stored = step ? undefined : state.evals[ply];
    const live = state.live?.fen === fen ? state.live.value : undefined;
    const score = retry ? retry.review.before.score : (stored ?? live)?.score;
    return { move, review, bestLine, step, fen, score, needsLive: !retry && !stored ? fen : null };
  }

  function render() {
    const v = view();
    renderBoard(v);
    renderEvalBar(v.score);
    renderPlayers(v.fen);
    renderSummary();
    renderAnalysisHeader();
    renderGraph();
    setHtml($('feedback'), state.retry ? retryHtml() : feedbackHtml(v));
    renderMoves();
    renderControls();
    updateLive(v.needsLive);
  }

  const squareXY = (square) => {
    const file = square.charCodeAt(0) - 97;
    const rank = Number(square[1]) - 1;
    return state.flipped ? { x: 7 - file, y: rank } : { x: file, y: 7 - rank };
  };

  function renderBoard(v) {
    const { retry } = state;
    const chess = new Chess(v.fen);
    const interactive = retry?.status === 'waiting';
    const meta = !retry && !v.step && v.review ? Lib.CLASSIFICATIONS[v.review.classification] : null;
    const last = retry ? retry.attempt : v.step ? Lib.splitUci(v.step.uci) : v.move;
    const marks = {};
    if (last) marks[last.from] = marks[last.to] = meta ? `${meta.color}80` : '#f6e05e77';
    if (chess.inCheck()) {
      const king = chess.board().flat().find((p) => p?.type === 'k' && p.color === chess.turn());
      marks[king.square] = 'radial-gradient(circle, #ef4444cc 30%, transparent 72%)';
    }
    if (state.selected) marks[state.selected] = '#60a5fa99';
    const targets = state.selected ? chess.moves({ square: state.selected, verbose: true }).map((m) => m.to) : [];
    const hint = retry?.hint && interactive ? retry.review.bestUci?.slice(0, 2) : null;

    let html = '';
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        const file = state.flipped ? 7 - x : x;
        const rank = state.flipped ? y : 7 - y;
        const square = 'abcdefgh'[file] + (rank + 1);
        const piece = chess.get(square);
        const classes = ['square', (file + rank) % 2 === 0 ? 'dark' : ''];
        if (targets.includes(square)) classes.push('target', piece ? 'occupied' : '');
        if (hint === square) classes.push('hint');
        if (interactive && piece?.color === chess.turn()) classes.push('movable');
        html += `<div class="${classes.join(' ')}" data-square="${square}"${marks[square] ? ` style="--mark:${marks[square]}"` : ''}>`;
        if (x === 0) html += `<span class="coord rank">${rank + 1}</span>`;
        if (y === 7) html += `<span class="coord file">${'abcdefgh'[file]}</span>`;
        if (piece) html += `<span class="piece ${piece.color}">${GLYPH[piece.type]}</span>`;
        html += '</div>';
      }
    }
    setHtml($('board'), html);
    $('board').classList.toggle('interactive', interactive);

    // Seta verde com o melhor lance.
    let best = null;
    if (retry) {
      if (retry.revealed && interactive) best = retry.review.bestUci;
    } else if (!v.step) best = v.review?.bestUci;
    let arrow = '';
    if (best) {
      const { from, to } = Lib.splitUci(best);
      const a = squareXY(from);
      const b = squareXY(to);
      const angle = (Math.atan2(b.y - a.y, b.x - a.x) * 180) / Math.PI;
      const length = Math.hypot(b.x - a.x, b.y - a.y);
      arrow = `<path transform="translate(${a.x + 0.5} ${a.y + 0.5}) rotate(${angle})" fill="#16a34a" opacity=".85" d="M.25-.09H${length - 0.4}V-.25L${length} 0 ${length - 0.4} .25V.09H.25Z"/>`;
    }
    setHtml($('arrows'), arrow);

    let overlay = '';
    if (meta && v.move) {
      const { x, y } = squareXY(v.move.to);
      overlay += `<span class="badge" style="left:${(x + 1) * 12.5}%;top:${y * 12.5}%;background:${meta.color}" title="${meta.label}">${meta.symbol}</span>`;
    }
    if (state.promotion) {
      overlay += '<div class="promotion">' +
        [['q', 'Dama'], ['r', 'Torre'], ['b', 'Bispo'], ['n', 'Cavalo']]
          .map(([p, label]) => `<button class="btn" data-action="promote" data-value="${p}" aria-label="${label}">${GLYPH[p]}</button>`)
          .join('') +
        '<button class="btn" data-action="cancel-promotion">Cancelar</button></div>';
    }
    setHtml($('overlay'), overlay);
  }

  function renderEvalBar(score) {
    const bar = $('evalbar');
    const white = score ? Lib.whiteWinChance(score) : 50;
    const label = bar.querySelector('span');
    bar.classList.toggle('flipped', state.flipped);
    bar.firstElementChild.style.height = `${white}%`;
    label.textContent = !score ? '…'
      : score.type === 'cp' ? Math.abs(score.value / 100).toFixed(1)
      : score.moves === 0 ? Lib.formatScore(score) : `M${score.moves}`;
    // O número fica na ponta do lado que está melhor.
    const atBottom = (white >= 50) !== state.flipped;
    label.style.bottom = atBottom ? '4px' : 'auto';
    label.style.top = atBottom ? 'auto' : '4px';
    label.style.color = white >= 50 ? '#0f172a' : '#f1f5f9';
    bar.setAttribute('aria-valuenow', Math.round(white));
    bar.title = score ? Lib.formatScore(score) : '';
  }

  function renderPlayers(fen) {
    const placement = fen.split(' ')[0];
    const count = (p) => placement.split(p).length - 1;
    const start = { p: 8, n: 2, b: 2, r: 2, q: 1 };
    const value = { p: 1, n: 3, b: 3, r: 5, q: 9 };
    const html = (color) => {
      const player = color === 'w' ? state.game.white : state.game.black;
      let captured = '';
      let balance = 0;
      for (const type in start) {
        const white = count(type.toUpperCase());
        const black = count(type);
        captured += GLYPH[type].repeat(Math.max(0, start[type] - (color === 'w' ? black : white)));
        balance += value[type] * (color === 'w' ? white - black : black - white);
      }
      const accuracy = state.accuracy?.[color];
      return `<span class="avatar ${color} ${fen.split(' ')[1] === color ? 'active' : ''}">♚&#xFE0E;</span>
        <div class="player-info"><b class="truncate">${escapeHtml(player.name)} ${player.rating ? `<span class="muted">(${escapeHtml(player.rating)})</span>` : ''}</b>
        <div class="captured truncate">${captured}${balance > 0 ? ` +${balance}` : ''}</div></div>
        ${accuracy != null ? `<span class="accuracy" title="Precisão">${accuracy.toFixed(1)}%</span>` : ''}`;
    };
    setHtml($('player-top'), html(state.flipped ? 'w' : 'b'));
    setHtml($('player-bottom'), html(state.flipped ? 'b' : 'w'));
  }

  const icon = (key, large) => {
    const m = Lib.CLASSIFICATIONS[key];
    return `<span class="icon ${large ? 'large' : ''}" style="background:${m.color}" title="${m.label}" role="img" aria-label="${m.label}">${m.symbol}</span>`;
  };

  function renderSummary() {
    const { game } = state;
    const { Event: event, Date: date } = game.headers;
    const count = (key, color) => state.reviews.filter((r, i) => r?.classification === key && game.moves[i].color === color).length;
    setHtml($('summary'), `
      <h2 class="truncate">${escapeHtml(event && event !== '?' ? event : 'Partida')}</h2>
      <p class="muted">${escapeHtml(date?.replace(/\.\?\?/g, ''))}</p>
      <p class="label">Precisão</p>
      <div class="accuracy-grid">${['w', 'b'].map((c) => `<div class="${c}"><strong>${state.accuracy?.[c]?.toFixed(1) ?? '—'}</strong>
        <p class="truncate">${escapeHtml(c === 'w' ? game.white.name : game.black.name)}</p></div>`).join('')}</div>
      <table class="counts">${Object.entries(Lib.CLASSIFICATIONS).map(([key, m]) =>
        `<tr><td>${count(key, 'w')}</td><td><span class="name">${icon(key)}${m.label}</span></td><td>${count(key, 'b')}</td></tr>`).join('')}</table>`);
  }

  function renderAnalysisHeader() {
    const o = state.opening;
    setHtml($('opening'), o
      ? `<p class="truncate" title="${escapeHtml(o.name)}"><span class="eco">${escapeHtml(o.eco || 'ECO ?')}</span>${escapeHtml(o.name)}</p>`
      : 'Abertura não identificada');
    const total = state.game.moves.length + 1;
    const progress = state.evals.length / total;
    setHtml($('status'), state.error
      ? `<div class="alert" role="alert">${escapeHtml(state.error)}<br><button class="btn" data-action="analyze">Tentar de novo</button></div>`
      : progress < 1
        ? `<div class="status">Analisando com Stockfish… ${Math.round(progress * 100)}%${state.evals.length ? '' : ' (a primeira vez baixa o motor)'}<progress max="1" value="${progress}"></progress></div>`
        : '');
  }

  function renderGraph(hover) {
    const total = state.game.moves.length;
    const px = (i) => (i / total) * 100;
    const py = (score) => 100 - Lib.whiteWinChance(score);
    const points = state.evals.map((e, i) => `${px(i)},${py(e.score)}`).join(' ');
    const focus = hover ?? state.ply;
    let html = `<svg viewBox="0 0 100 100" preserveAspectRatio="none">
      ${state.evals.length > 1 ? `<polygon fill="#e2e8f0" points="0,100 ${points} ${px(state.evals.length - 1)},100"/>` : ''}
      <line x1="0" x2="100" y1="50" y2="50" stroke="#888f9c" stroke-dasharray="4 4" vector-effect="non-scaling-stroke"/>
      <line x1="${px(state.ply)}" x2="${px(state.ply)}" y1="0" y2="100" stroke="#7fc243" stroke-width="2" vector-effect="non-scaling-stroke"/></svg>`;
    state.evals.forEach((e, i) => {
      const r = state.reviews[i - 1];
      if (i !== focus && !(r && NOTABLE.includes(r.classification))) return;
      const color = r ? Lib.CLASSIFICATIONS[r.classification].color : '#7fc243';
      html += `<span class="dot" style="left:${px(i)}%;top:${py(e.score)}%;background:${color}"></span>`;
    });
    if (state.evals[focus] && focus > 0) {
      html += `<span class="graph-label">${Math.ceil(focus / 2)}${focus % 2 ? '.' : '…'} ${escapeHtml(state.game.moves[focus - 1].san)} · ${Lib.formatScore(state.evals[focus].score)}</span>`;
    }
    const graph = $('graph');
    setHtml(graph, html);
    graph.setAttribute('aria-valuemin', 0);
    graph.setAttribute('aria-valuemax', total);
    graph.setAttribute('aria-valuenow', state.ply);
  }

  function feedbackHtml({ move, review, bestLine }) {
    if (!move) return '<div class="card muted">Avance pelos lances (setas ← →) ou clique no gráfico para ver a avaliação de cada jogada.</div>';
    if (!review) return `<div class="card muted">Analisando ${escapeHtml(move.san)}…</div>`;
    const meta = Lib.CLASSIFICATIONS[review.classification];
    const replyPv = review.after.lines[0]?.pv;
    const replySan = replyPv ? Lib.lineToSteps(move.fenAfter, replyPv, 1)[0]?.san : undefined;
    const text = Lib.explainMove(move, review, { bestSan: bestLine[0]?.san, replySan });
    const canRetry = Lib.isError(review.classification) && review.bestUci;
    return `<article class="card">
      <header class="card-head">${icon(review.classification, true)}<div>
        <p><b>${escapeHtml(move.san)} <span style="color:${meta.color}">· ${meta.label}</span></b></p>
        <p class="muted">Avaliação ${Lib.formatScore(review.before.score)} → ${Lib.formatScore(review.after.score)}</p></div></header>
      ${text.map((t) => `<p>${escapeHtml(t)}</p>`).join('')}
      ${bestLine.length ? `<p class="label">Linha recomendada (profundidade ${review.before.lines[0].depth})</p>
        <div class="line">${bestLine.map((s, i) => `<button data-action="preview" data-value="${i}" class="${state.preview === i ? 'active' : ''}">${escapeHtml(s.label)}</button>`).join('')}</div>` : ''}
      <div class="row">${canRetry ? '<button class="btn primary" data-action="retry">↻ Tentar novamente</button>' : ''}
        ${state.preview !== null ? '<button class="btn" data-action="unpreview">Voltar à partida</button>' : ''}</div></article>`;
  }

  function retryHtml() {
    const r = state.retry;
    return `<article class="card ${r.status}">
      <p><b>Sua vez: jogam as ${r.move.color === 'w' ? 'brancas' : 'pretas'}</b></p>
      <p class="muted">Na partida foi jogado ${escapeHtml(r.move.san)}.</p>
      <p>${escapeHtml(r.message)}</p>
      <div class="row">
        ${r.status === 'waiting' && !r.revealed ? `<button class="btn" data-action="hint" ${r.hint ? 'disabled' : ''}>💡 Dica</button><button class="btn" data-action="reveal">Ver solução</button>` : ''}
        ${r.status === 'wrong' || r.status === 'solved' ? '<button class="btn" data-action="retry">↻ Tentar de novo</button>' : ''}
        <button class="btn primary" data-action="exit-retry">Voltar à análise</button></div></article>`;
  }

  let shownPly = -1;
  function renderMoves() {
    const { game, ply } = state;
    const firstNumber = Number(game.startFen.split(' ')[5]) || 1;
    const cells = game.moves.map((_, i) => i);
    if (game.moves[0].color === 'b') cells.unshift(null);
    let html = '';
    for (let i = 0; i < cells.length; i += 2) {
      html += `<div class="move-row"><span>${firstNumber + i / 2}.</span>`;
      for (const n of cells.slice(i, i + 2)) {
        if (n === null) html += '<span>…</span>';
        else {
          const r = state.reviews[n];
          html += `<button data-action="goto" data-value="${n + 1}" ${ply === n + 1 ? 'aria-current="step"' : ''}>${r ? icon(r.classification) : '<span class="icon"></span>'}${escapeHtml(game.moves[n].san)}</button>`;
        }
      }
      html += '</div>';
    }
    const list = $('moves');
    const top = list.scrollTop;
    setHtml(list, `${html}<p class="result">${escapeHtml(game.result)}</p>`);
    list.scrollTop = top;
    if (shownPly === ply) return;
    shownPly = ply;
    // Rola somente a lista, sem mover a página.
    const active = list.querySelector('[aria-current]');
    if (!active) { list.scrollTop = 0; return; }
    const a = active.getBoundingClientRect();
    const l = list.getBoundingClientRect();
    if (a.top < l.top) list.scrollTop -= l.top - a.top;
    else if (a.bottom > l.bottom) list.scrollTop += a.bottom - l.bottom;
  }

  function renderControls() {
    const atStart = state.ply === 0;
    const atEnd = state.ply === state.game.moves.length;
    for (const button of document.querySelectorAll('.controls button')) {
      const action = button.dataset.action;
      button.disabled = (atStart && (action === 'first' || action === 'prev')) || (atEnd && (action === 'next' || action === 'last'));
    }
    $('play').textContent = playTimer ? '⏸︎' : '▶︎';
    $('mute').textContent = state.muted ? '🔇' : '🔊';
    $('mute').setAttribute('aria-label', state.muted ? 'Ativar sons' : 'Silenciar');
  }

  /* ---------- Lances no tabuleiro ---------- */

  function tryMove(from, to) {
    const options = new Chess(state.retry.fen).moves({ square: from, verbose: true }).filter((m) => m.to === to);
    state.selected = null;
    if (!options.length) return render();
    if (options[0].promotion) {
      state.promotion = { from, to };
      return render();
    }
    attempt(from, to);
  }

  let drag = null;

  $('board').addEventListener('pointerdown', (event) => {
    const square = event.target.closest('[data-square]')?.dataset.square;
    if (!square || state.retry?.status !== 'waiting' || event.button !== 0) return;
    const chess = new Chess(state.retry.fen);
    if (state.selected && chess.moves({ square: state.selected, verbose: true }).some((m) => m.to === square)) {
      return tryMove(state.selected, square);
    }
    const piece = chess.get(square);
    if (piece?.color !== chess.turn()) {
      state.selected = null;
      return render();
    }
    event.preventDefault();
    state.selected = square;
    drag = { from: square, piece, x: event.clientX, y: event.clientY, ghost: null };
    render();
  });

  window.addEventListener('pointermove', (event) => {
    if (!drag) return;
    if (!drag.ghost) {
      if (Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 5) return;
      drag.ghost = document.createElement('span');
      drag.ghost.className = `piece ghost ${drag.piece.color}`;
      drag.ghost.textContent = GLYPH[drag.piece.type];
      drag.ghost.style.fontSize = `${$('board').clientWidth / 10}px`;
      document.body.append(drag.ghost);
    }
    drag.ghost.style.left = `${event.clientX}px`;
    drag.ghost.style.top = `${event.clientY}px`;
  });

  function endDrag(event) {
    if (!drag) return;
    const { from, ghost } = drag;
    drag = null;
    if (!ghost) return;
    ghost.remove();
    const to = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-square]')?.dataset.square;
    if (event.type === 'pointerup' && to && to !== from && state.retry?.status === 'waiting') tryMove(from, to);
  }
  window.addEventListener('pointerup', endDrag);
  window.addEventListener('pointercancel', endDrag);

  /* ---------- Importação ---------- */

  const dialog = $('dialog');
  let source = 'pgn';
  let searchAbort;
  let found = [];

  function selectTab(tab) {
    source = tab;
    searchAbort?.abort();
    found = [];
    $('results').innerHTML = '';
    $('dialog-error').textContent = '';
    for (const button of dialog.querySelectorAll('[data-tab]')) button.setAttribute('aria-selected', button.dataset.tab === tab);
    $('pgn-form').hidden = tab !== 'pgn';
    $('search').hidden = tab === 'pgn';
    const label = `Usuário no ${tab === 'lichess' ? 'Lichess' : 'Chess.com'}`;
    $('username').placeholder = label;
    $('username').setAttribute('aria-label', label);
  }

  function importPgn(pgn) {
    try {
      const game = Lib.parsePgn(pgn);
      searchAbort?.abort();
      dialog.close();
      loadGame(game);
    } catch (error) {
      $('dialog-error').textContent = error.message;
    }
  }

  $('pgn-form').addEventListener('submit', (event) => {
    event.preventDefault();
    importPgn($('pgn').value);
  });

  $('file').addEventListener('change', async (event) => {
    const file = event.target.files[0];
    if (file) $('pgn').value = await file.text();
  });

  $('search-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const username = $('username').value.trim();
    if (!username) return;
    searchAbort?.abort();
    const abort = (searchAbort = new AbortController());
    $('dialog-error').textContent = '';
    $('results').innerHTML = '<li class="muted">Buscando…</li>';
    try {
      const load = source === 'lichess' ? Lib.fetchLichessGames : Lib.fetchChessComGames;
      const games = await load(username, abort.signal);
      if (abort.signal.aborted) return;
      found = games;
      $('results').innerHTML = games.length
        ? games.map((g, i) => `<li><button data-action="pick" data-value="${i}">
            <span class="names"><div>□ ${escapeHtml(g.white.name)} <span class="muted">${escapeHtml(g.white.rating)}</span></div>
            <div>■ ${escapeHtml(g.black.name)} <span class="muted">${escapeHtml(g.black.rating)}</span></div></span>
            <span class="meta"><b>${g.result}</b><br><span class="muted">${escapeHtml(g.speed)} · ${new Date(g.date).toLocaleDateString('pt-BR')}</span></span></button></li>`).join('')
        : '<li class="muted">Nenhuma partida de xadrez padrão encontrada.</li>';
    } catch (error) {
      if (abort.signal.aborted) return;
      $('results').innerHTML = '';
      // fetch lança TypeError em falhas de rede.
      $('dialog-error').textContent = error instanceof TypeError ? 'Não foi possível conectar. Verifique sua internet.' : error.message;
    }
  });

  /* ---------- Eventos gerais ---------- */

  const actions = {
    first: () => jump(0),
    prev: () => jump(state.ply - 1),
    next: () => jump(state.ply + 1),
    last: () => jump(state.game.moves.length),
    goto: (value) => jump(Number(value)),
    play: togglePlay,
    flip: () => { state.flipped = !state.flipped; render(); },
    mute: () => { state.muted = !state.muted; render(); },
    analyze,
    import: () => { pause(); selectTab(source); render(); dialog.showModal(); },
    close: () => dialog.close(),
    sample: () => { $('pgn').value = Lib.SAMPLE_PGN; },
    pick: (value) => importPgn(found[value].pgn),
    preview: (value) => {
      state.preview = Number(value);
      const step = view().bestLine[state.preview];
      if (step) sound(Lib.soundForSan(step.san, false));
      render();
    },
    unpreview: () => { state.preview = null; render(); },
    retry: startRetry,
    'exit-retry': () => { stopRetry(); render(); },
    hint: () => { state.retry.hint = true; render(); },
    reveal: () => {
      Object.assign(state.retry, { revealed: true, message: 'A seta verde mostra a solução. Jogue-a no tabuleiro.' });
      render();
    },
    promote: (value) => {
      const { from, to } = state.promotion;
      state.promotion = null;
      attempt(from, to, value);
    },
    'cancel-promotion': () => { state.promotion = null; render(); },
  };

  document.addEventListener('click', (event) => {
    const tab = event.target.closest('[data-tab]');
    if (tab) return selectTab(tab.dataset.tab);
    const element = event.target.closest('[data-action]');
    if (element) actions[element.dataset.action]?.(element.dataset.value);
  });

  document.addEventListener('keydown', (event) => {
    if (dialog.open || event.ctrlKey || event.metaKey || event.altKey) return;
    if (event.target.closest?.('input, textarea, select')) return;
    if (event.key === ' ' && event.target.closest?.('button')) return;
    const keys = { ArrowLeft: 'prev', ArrowRight: 'next', ArrowUp: 'first', ArrowDown: 'last', Home: 'first', End: 'last', f: 'flip', ' ': 'play' };
    const action = keys[event.key];
    if (!action) return;
    event.preventDefault();
    actions[action]();
  });

  const graphPly = (event) => {
    const box = $('graph').getBoundingClientRect();
    const total = state.game.moves.length;
    return Math.max(0, Math.min(total, Math.round(((event.clientX - box.left) / box.width) * total)));
  };
  $('graph').addEventListener('click', (event) => jump(graphPly(event)));
  $('graph').addEventListener('mousemove', (event) => renderGraph(graphPly(event)));
  $('graph').addEventListener('mouseleave', () => renderGraph());
  $('preset').addEventListener('change', analyze);

  loadGame(Lib.parsePgn(Lib.SAMPLE_PGN));
})();
