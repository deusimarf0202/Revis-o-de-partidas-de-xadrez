/* Regras do xadrez: lances legais, FEN, SAN e PGN. Expõe window.Chess. */
(function (global) {
  'use strict';

  const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  const FILES = 'abcdefgh';
  const KNIGHT = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
  const KING = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
  const DIAGONAL = [[1, 1], [-1, 1], [-1, -1], [1, -1]];
  const STRAIGHT = [[1, 0], [0, 1], [-1, 0], [0, -1]];

  // Casas numeradas de 0 (a1) a 63 (h8).
  const name = (i) => FILES[i % 8] + (Math.floor(i / 8) + 1);
  const index = (sq) => FILES.indexOf(sq[0]) + 8 * (Number(sq[1]) - 1);
  const colorOf = (p) => (p === p.toUpperCase() ? 'w' : 'b');
  const offset = (i, df, dr) => {
    const f = (i % 8) + df;
    const r = Math.floor(i / 8) + dr;
    return f >= 0 && f < 8 && r >= 0 && r < 8 ? r * 8 + f : -1;
  };

  class Chess {
    constructor(fen = START) {
      this.load(fen);
    }

    load(fen) {
      const [placement, turn = 'w', castling = '-', ep = '-', half = '0', full = '1'] = fen.trim().split(/\s+/);
      const rows = placement.split('/');
      if (rows.length !== 8) throw new Error('FEN inválido');
      this._board = Array(64).fill('');
      rows.forEach((row, r) => {
        let f = 0;
        for (const c of row) {
          if (/[1-8]/.test(c)) f += Number(c);
          else if (/[pnbrqk]/i.test(c) && f < 8) this._board[(7 - r) * 8 + f++] = c;
          else throw new Error('FEN inválido');
        }
        if (f !== 8) throw new Error('FEN inválido');
      });
      if (!this._board.includes('K') || !this._board.includes('k')) throw new Error('FEN sem rei');
      this._turn = turn === 'b' ? 'b' : 'w';
      this._castling = castling === '-' ? '' : castling;
      this._ep = ep === '-' ? -1 : index(ep);
      this._half = Number(half) || 0;
      this._full = Number(full) || 1;
      this._stack = [];
      this._history = [];
      this._headers = {};
    }

    fen() {
      const rows = [];
      for (let r = 7; r >= 0; r--) {
        let row = '';
        let empty = 0;
        for (let f = 0; f < 8; f++) {
          const p = this._board[r * 8 + f];
          if (!p) empty++;
          else {
            row += (empty || '') + p;
            empty = 0;
          }
        }
        rows.push(row + (empty || ''));
      }
      // A casa de en passant só aparece quando a captura é possível.
      const ep = this._ep >= 0 && this._legal().some((m) => m.flag === 'ep') ? name(this._ep) : '-';
      return `${rows.join('/')} ${this._turn} ${this._castling || '-'} ${ep} ${this._half} ${this._full}`;
    }

    turn() { return this._turn; }
    moveNumber() { return this._full; }
    getHeaders() { return { ...this._headers }; }

    get(square) {
      const p = this._board[index(square)];
      return p ? { type: p.toLowerCase(), color: colorOf(p) } : undefined;
    }

    board() {
      return Array.from({ length: 8 }, (_, row) =>
        Array.from({ length: 8 }, (_, f) => {
          const square = name((7 - row) * 8 + f);
          const piece = this.get(square);
          return piece ? { square, ...piece } : null;
        }),
      );
    }

    _attacked(i, by) {
      const is = (j, type) => j >= 0 && this._board[j] === (by === 'w' ? type.toUpperCase() : type);
      const dir = by === 'w' ? -1 : 1;
      if (is(offset(i, -1, dir), 'p') || is(offset(i, 1, dir), 'p')) return true;
      if (KNIGHT.some(([f, r]) => is(offset(i, f, r), 'n'))) return true;
      if (KING.some(([f, r]) => is(offset(i, f, r), 'k'))) return true;
      const ray = (dirs, types) =>
        dirs.some(([f, r]) => {
          let j = offset(i, f, r);
          while (j >= 0 && !this._board[j]) j = offset(j, f, r);
          return types.some((t) => is(j, t));
        });
      return ray(DIAGONAL, ['b', 'q']) || ray(STRAIGHT, ['r', 'q']);
    }

    _inCheck(color) {
      const king = this._board.indexOf(color === 'w' ? 'K' : 'k');
      return this._attacked(king, color === 'w' ? 'b' : 'w');
    }

    inCheck() { return this._inCheck(this._turn); }

    _pseudo() {
      const moves = [];
      const us = this._turn;
      const add = (from, to, extra = {}) => {
        const piece = this._board[from].toLowerCase();
        const captured = extra.flag === 'ep' ? 'p' : this._board[to] ? this._board[to].toLowerCase() : undefined;
        if (piece === 'p' && (to >= 56 || to < 8)) {
          for (const promotion of ['q', 'r', 'b', 'n']) moves.push({ from, to, piece, captured, promotion });
        } else moves.push({ from, to, piece, captured, ...extra });
      };

      for (let i = 0; i < 64; i++) {
        const p = this._board[i];
        if (!p || colorOf(p) !== us) continue;
        const type = p.toLowerCase();

        if (type === 'p') {
          const dir = us === 'w' ? 1 : -1;
          const one = offset(i, 0, dir);
          if (one >= 0 && !this._board[one]) {
            add(i, one);
            const two = offset(i, 0, 2 * dir);
            if (Math.floor(i / 8) === (us === 'w' ? 1 : 6) && !this._board[two]) add(i, two, { flag: 'double' });
          }
          for (const df of [-1, 1]) {
            const to = offset(i, df, dir);
            if (to < 0) continue;
            if (this._board[to] && colorOf(this._board[to]) !== us) add(i, to);
            else if (to === this._ep) add(i, to, { flag: 'ep' });
          }
          continue;
        }

        const slides = type === 'b' || type === 'r' || type === 'q';
        const dirs = type === 'n' ? KNIGHT : type === 'b' ? DIAGONAL : type === 'r' ? STRAIGHT : KING;
        for (const [f, r] of dirs) {
          let to = offset(i, f, r);
          while (to >= 0) {
            const target = this._board[to];
            if (!target || colorOf(target) !== us) add(i, to);
            if (target || !slides) break;
            to = offset(to, f, r);
          }
        }

        if (type === 'k' && i === (us === 'w' ? 4 : 60) && !this._inCheck(us)) {
          const them = us === 'w' ? 'b' : 'w';
          const rook = us === 'w' ? 'R' : 'r';
          const free = (...list) => list.every((j) => !this._board[j]);
          const safe = (...list) => list.every((j) => !this._attacked(j, them));
          if (this._castling.includes(us === 'w' ? 'K' : 'k') && this._board[i + 3] === rook && free(i + 1, i + 2) && safe(i + 1, i + 2)) {
            add(i, i + 2, { flag: 'short' });
          }
          if (this._castling.includes(us === 'w' ? 'Q' : 'q') && this._board[i - 4] === rook && free(i - 1, i - 2, i - 3) && safe(i - 1, i - 2)) {
            add(i, i - 2, { flag: 'long' });
          }
        }
      }
      return moves;
    }

    _make(m) {
      this._stack.push([this._board.slice(), this._turn, this._castling, this._ep, this._half, this._full]);
      const b = this._board;
      const us = this._turn;
      b[m.to] = m.promotion ? (us === 'w' ? m.promotion.toUpperCase() : m.promotion) : b[m.from];
      b[m.from] = '';
      if (m.flag === 'ep') b[m.to + (us === 'w' ? -8 : 8)] = '';
      if (m.flag === 'short') { b[m.from + 1] = b[m.from + 3]; b[m.from + 3] = ''; }
      if (m.flag === 'long') { b[m.from - 1] = b[m.from - 4]; b[m.from - 4] = ''; }
      // Perde o direito de rocar quando o rei ou a torre saem (ou a torre é capturada).
      const lost = { 4: 'KQ', 0: 'Q', 7: 'K', 60: 'kq', 56: 'q', 63: 'k' };
      for (const sq of [m.from, m.to]) {
        for (const right of lost[sq] || '') this._castling = this._castling.replace(right, '');
      }
      this._ep = m.flag === 'double' ? (m.from + m.to) / 2 : -1;
      this._half = m.piece === 'p' || m.captured ? 0 : this._half + 1;
      if (us === 'b') this._full++;
      this._turn = us === 'w' ? 'b' : 'w';
    }

    _unmake() {
      [this._board, this._turn, this._castling, this._ep, this._half, this._full] = this._stack.pop();
    }

    _legal() {
      return this._pseudo().filter((m) => {
        const us = this._turn;
        this._make(m);
        const ok = !this._inCheck(us);
        this._unmake();
        return ok;
      });
    }

    _san(m, legal) {
      let san;
      if (m.flag === 'short') san = 'O-O';
      else if (m.flag === 'long') san = 'O-O-O';
      else {
        const to = name(m.to);
        if (m.piece === 'p') san = (m.captured ? name(m.from)[0] + 'x' : '') + to;
        else {
          const twins = legal.filter((o) => o.piece === m.piece && o.to === m.to && o.from !== m.from);
          let from = '';
          if (twins.length) {
            if (!twins.some((o) => o.from % 8 === m.from % 8)) from = name(m.from)[0];
            else if (!twins.some((o) => Math.floor(o.from / 8) === Math.floor(m.from / 8))) from = name(m.from)[1];
            else from = name(m.from);
          }
          san = m.piece.toUpperCase() + from + (m.captured ? 'x' : '') + to;
        }
        if (m.promotion) san += '=' + m.promotion.toUpperCase();
      }
      this._make(m);
      if (this.inCheck()) san += this._legal().length ? '+' : '#';
      this._unmake();
      return san;
    }

    _describe(m, legal) {
      const color = this._turn;
      const san = this._san(m, legal);
      const before = this.fen();
      this._make(m);
      const after = this.fen();
      this._unmake();
      return { color, piece: m.piece, captured: m.captured, promotion: m.promotion, from: name(m.from), to: name(m.to), san, before, after };
    }

    moves({ square, verbose } = {}) {
      const legal = this._legal();
      const list = square ? legal.filter((m) => name(m.from) === square) : legal;
      return list.map((m) => (verbose ? this._describe(m, legal) : this._san(m, legal)));
    }

    /** Aceita SAN ("Nf3") ou { from, to, promotion }. Lança erro se o lance for ilegal. */
    move(input) {
      const legal = this._legal();
      let found;
      if (typeof input === 'string') {
        const clean = (s) => s.replace(/0/g, 'O').replace(/[+#!?=]/g, '');
        const wanted = clean(input);
        found = legal.find((m) => clean(this._san(m, legal)) === wanted);
        if (!found) {
          // Notação longa, como "Ng1f3" ou "e2-e4".
          const long = /^[KQRBN]?([a-h][1-8])[-x]?([a-h][1-8])([QRBN])?$/i.exec(wanted);
          if (long) return this.move({ from: long[1], to: long[2], promotion: long[3] && long[3].toLowerCase() });
        }
      } else {
        found = legal.find(
          (m) => name(m.from) === input.from && name(m.to) === input.to && (!m.promotion || m.promotion === input.promotion),
        );
      }
      if (!found) throw new Error(`Lance ilegal: ${typeof input === 'string' ? input : input.from + input.to}`);
      const record = this._describe(found, legal);
      this._make(found);
      this._history.push(record);
      return record;
    }

    undo() {
      if (!this._stack.length) return null;
      this._unmake();
      return this._history.pop();
    }

    history({ verbose } = {}) {
      return this._history.map((m) => (verbose ? { ...m } : m.san));
    }

    isCheckmate() { return this.inCheck() && !this._legal().length; }
    isStalemate() { return !this.inCheck() && !this._legal().length; }

    isInsufficientMaterial() {
      const others = this._board.map((p, i) => [p.toLowerCase(), i]).filter(([p]) => p && p !== 'k');
      if (!others.length) return true;
      if (others.length === 1) return 'bn'.includes(others[0][0]);
      const shade = (i) => ((i % 8) + Math.floor(i / 8)) % 2;
      return others.every(([p, i]) => p === 'b' && shade(i) === shade(others[0][1]));
    }

    loadPgn(pgn) {
      const headers = {};
      const body = pgn.replace(/^\s*\[(\w+)\s+"((?:\\.|[^"\\])*)"\]\s*$/gm, (_, key, value) => {
        headers[key] = value.replace(/\\(["\\])/g, '$1');
        return '';
      });
      let text = body.replace(/\{[^}]*\}/g, ' ').replace(/;[^\n]*/g, ' ').replace(/^%.*$/gm, ' ');
      // Remove variantes entre parênteses, inclusive aninhadas.
      for (let previous = ''; previous !== text; ) {
        previous = text;
        text = text.replace(/\([^()]*\)/g, ' ');
      }
      this.load(headers.FEN || START);
      this._headers = headers;
      for (const raw of text.split(/\s+/)) {
        const token = raw.replace(/^\d+\.(\.\.)?\.*/, '');
        if (!token || /^(\$\d+|1-0|0-1|1\/2-1\/2|\*|\.+|[!?]+|e\.p\.)$/.test(token)) continue;
        this.move(token);
      }
    }
  }

  global.Chess = Chess;
  global.DEFAULT_POSITION = START;
})(globalThis);
